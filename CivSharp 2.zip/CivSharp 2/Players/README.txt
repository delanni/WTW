﻿CivSharpGame/Players
====================

* Ebbe a mappábba kell elhelyezdned a játékban résztvevő játékosok dll-jeit.
* Legfeljebb négy ilyen dll-t helyezhetsz el.